#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 12 14:31:34 2018

@author: robertluo
"""

import numpy as np
import pandas as pd


#k_values = [1,3,5,7,9,11,13,15,17,19,21]
k_values = [20]
test_or_validate = 'test'


df_train = pd.read_csv('processed_data/user_restaurant_stars_train.csv',index_col=0)
if test_or_validate =='validate':
    df_validate = pd.read_csv('processed_data/user_restaurant_stars_validation.csv',index_col=0)
elif test_or_validate =='test':
    df_validate = pd.read_csv('processed_data/user_restaurant_stars_test.csv',index_col=0)
#train_matrix = np.array(df_train)
#test_matrix = np.array(df_test)

restaurant_df = pd.read_csv('processed_data/us_restaurant_data_processed_wIndex.csv',index_col=0)
restaurant_inds = [x in df_train.columns for x in restaurant_df.index]
restaurant_df = restaurant_df.loc[restaurant_inds]

restaurant_rating_df = pd.DataFrame(np.nan,index=restaurant_df.index,columns=['lowStars','medStars','highStars'])
for index,row in restaurant_df.iterrows():
    c = row['Class']
    if c == 'L':
        restaurant_rating_df.loc[index,'lowStars'] = 1
    elif c == 'M':
        restaurant_rating_df.loc[index,'medStars'] = 1
    else:
        restaurant_rating_df.loc[index,'highStars'] = 1
del restaurant_df['Class']
restaurant_df = pd.concat([restaurant_df,restaurant_rating_df],axis=1)
restaurant_df = restaurant_df.fillna(0)
restaurant_matrix = np.array(restaurant_df)


restaurant_np = np.array(restaurant_df)
restaurant_names = restaurant_df.index.tolist()

def stack_reviews(df):
    reviews = df.unstack().reset_index('user_id')
    reviews['restaurant_id'] = reviews.index
    reviews=reviews.set_index('user_id')
    reviews.columns= ['rating', 'restaurant_id']
    reviews = reviews.loc[reviews['rating'] >0]
    return reviews
train_reviews = stack_reviews(df_train)
validation_reviews = stack_reviews(df_validate)

    

def predict_knn_rating(train,test,neighbors,k):
    pred_vals= np.zeros(shape=(len(test),))
    true_vals= np.zeros(shape=(len(test),))
    for usr_num in range(len(test)):
        if usr_num%500.0==1: print usr_num

        usr_rev = test.iloc[usr_num]
        user_id=usr_rev.name
        test_restaurant = usr_rev.restaurant_id
        true_vals[usr_num]=usr_rev.rating

        user_ratings = train[train.index==user_id]
        restaurant_ids = user_ratings['restaurant_id'].tolist()
        restaurant_id_indices = [restaurant_names.index(x) for x in restaurant_ids]

        if len(restaurant_ids) >= k:
            ratings = user_ratings['rating']
            restaurant_attributes = restaurant_np[restaurant_id_indices]
            neighbors.fit(restaurant_attributes,np.ravel(ratings))
            pred = neighbors.predict(restaurant_np[restaurant_names.index(test_restaurant)].reshape(1,-1))
            #print pred[0]
            pred_vals[usr_num] = pred[0]
        else:
            pass
    return true_vals,pred_vals


def label_HL(ratings):
    classifications = []
    for r in ratings:
        if r <=3:
            classifications.append('L')
        elif r > 3:
            classifications.append('H')
    return classifications


# ~~~~~~~~~~~~~ RUN THE MODEL ~~~~~~~~~~~~~~~~~
   
# RUN THE MODEL WITH VARIOUS K's ON VALIDATION SET TO CHOOSE K VALUE
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import precision_score,recall_score



results = pd.DataFrame(index=k_values,columns=['rmse','mae','recall','precision','accuracy'])


for k in k_values:
    print "k value:",k
    neighbors = KNeighborsClassifier(n_neighbors=k,metric='cosine')
    true_vals,pred_vals=predict_knn_rating(train_reviews,validation_reviews,neighbors,k)

    tmp_true = true_vals[pred_vals!=0]
    tmp_pred = pred_vals[pred_vals!=0]    
    
    rmse = np.sqrt(sum(np.square(tmp_true-tmp_pred))/len(tmp_true))
    results.loc[k,'rmse'] = rmse
    print "k value:",k,",rmse:",rmse
    
    mae = sum(abs(tmp_true-tmp_pred))/len(tmp_true)
    results.loc[k,'mae'] = mae
    print "k value:",k,",mae:",mae
    
    #Define "high" as 4 or higher stars
    true_val_classes = label_HL(tmp_true)
    pred_val_classes = label_HL(tmp_pred)
    
    results.loc[k,'recall'] = recall_score(true_val_classes,pred_val_classes,pos_label='H')
    results.loc[k,'precision']= precision_score(true_val_classes,pred_val_classes,pos_label='H')
    results.loc[k,'accuracy'] = sum(np.array(true_val_classes) == np.array(pred_val_classes))/float(len(true_val_classes))



import matplotlib.pyplot as plt
import seaborn as sns
sns.set()

pal = sns.color_palette("Set2", 5)

plt.figure(figsize=(8, 6))
plt.plot(results.index, results['recall'], c=pal[0], label='Recall', alpha=0.5, linewidth=5)
plt.plot(results.index, results['precision'], c=pal[1], label='Precision', linewidth=5)
plt.plot(results.index, results['accuracy'], c=pal[2], label='Accuracy', alpha=0.5, linewidth=5)
plt.legend(loc='best', fontsize=20)
plt.xticks(fontsize=16);
plt.yticks(fontsize=16);
plt.xlabel('K', fontsize=24);
plt.title('K-NN Performance on Validation Data',fontsize=26)
