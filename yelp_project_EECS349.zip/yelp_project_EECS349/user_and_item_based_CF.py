#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 13 03:41:08 2018

@author: robertluo
"""

#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 12 13:21:17 2018

@author: robertluo
"""

import numpy as np
import pandas as pd

df_train = pd.read_csv('processed_data/user_restaurant_stars_train.csv',index_col=0)
df_test = pd.read_csv('processed_data/user_restaurant_stars_validation.csv',index_col=0)
train_matrix = np.array(df_train)
test_matrix = np.array(df_test)


from sklearn.metrics.pairwise import pairwise_distances
user_similarity = pairwise_distances(train_matrix, metric='cosine')
item_similarity = pairwise_distances(train_matrix.T, metric='cosine')




# ~~~~~~~~~~ USER-ITEM: COLLABORATIVE FILTERING ~~~~~~~~~~
def predict(ratings, similarity, type='user'): # removes bias of user average ratings
    if type == 'user':
        mean_user_rating = ratings.mean(axis=1)
        #You use np.newaxis so that mean_user_rating has same format as ratings
        ratings_diff = (ratings - mean_user_rating[:, np.newaxis])
        pred = mean_user_rating[:, np.newaxis] + similarity.dot(ratings_diff) / np.array([np.abs(similarity).sum(axis=1)]).T
    elif type == 'item':
        pred = ratings.dot(similarity) / np.array([np.abs(similarity).sum(axis=1)])
    return pred

item_prediction = predict(train_matrix, item_similarity, type='item')
user_prediction = predict(train_matrix, user_similarity, type='user')

from sklearn.metrics import mean_squared_error, mean_absolute_error
from math import sqrt
def error(prediction, ground_truth):
    prediction = prediction[ground_truth.nonzero()].flatten()
    ground_truth = ground_truth[ground_truth.nonzero()].flatten()
    root_mse= sqrt(mean_squared_error(prediction, ground_truth))
    mae = mean_absolute_error(prediction, ground_truth)
    return root_mse,mae

user_rmse,user_mae = error(user_prediction, test_matrix)
item_rmse,item_mae = error(item_prediction, test_matrix)
print 'User-based CF RMSE: ' + str(user_rmse)
print 'User-based CF MAE: ' + str(user_mae)
print 'Item-based CF RMSE: ' + str(item_rmse)
print 'Item-based CF MAE: ' + str(item_mae)

